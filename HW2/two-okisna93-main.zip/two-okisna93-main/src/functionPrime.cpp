#include <iostream>
#include<cmath>

using namespace std;
// Write code that check if number is prime or not

void isPrime(int x) {

    // write your code here
    // consider  a special case in your function, i.e., x = 1 is not prime.
    // no return value just print if prime or not

}