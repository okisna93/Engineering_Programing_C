#ifndef FUNCTIONPRIME_H
#define FUNCTIONPRIME_H

extern bool prime;
void isPrime(int x);

#endif
