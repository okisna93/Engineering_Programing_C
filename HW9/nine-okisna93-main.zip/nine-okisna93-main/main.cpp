#include <iostream>

using namespace std;

// -------------- Design Matrix class here ---------------
// -----------------------------------------------------------
// private variable and member function:
//  Variables number of rows, number of columns, type_double pointer to pointer m for the matrix (** m), you can use m[i_idx][j_idx]
//  You can use int or uint_32_t (unsigned) for number of rows and columns
//  Private member function, utility function:
//  This function set up the Matrix and create dynamic array pointer in row and each row point array of columns
//  Matrix(uint32_t rows, uint32_t cols) : rows(rows), cols(cols), m(new double*[rows]){
//  Write here your code
//  loop each pointer rows[idx] and for each row create array of size columns
//  }
// make the following functions
//  1. Constructor that take #of rows and #of columns and initial value for all elements
//     Matrix G(2, 2, 0) ===>
//                                 index_0  index_1
//                       index_0     0       0
//                       index_1     0       0
//  2. Copy constructor
//  3. Assign operator = for copy constructor
//     - use swap(new_matrix, original_matrix)
//  4. Deconstruct  ~Matrix: loop inside each pointer and delete it
//  5. Move constructor
//  6. Overload () operator twice:
//     - first: return_type is double and member function is const
//     - second: return_type is reference double and member function is not const
//  7. overload [] operator
//     - return_type double pointer
//  8. Overload << operator to print out matrix similar to:
//                            0   0
//                            0   0


int main() {
    cout << "########" << endl;
    cout << "Main Problem" << endl;
    cout << "########" << endl;

    // Create matrix a with 4 rows and 3 columns filled with values in zero
    Matrix a(4, 3, 0.0);
    // print out the complete matrix
    cout << a << endl;
    // print out one element in the matrix
    // overload of () return const value
    cout << a(2,3) << endl;
    // change one element in a(2,2) equal 1.5
    // overload of () assign reference to 1.5
    a(2,2) = 1.5;
    // print out one element in the matrix
    cout << "\n" << a << endl;
    // change one element in a(2,1) using operator [] ==> a[2][1] equal 2.5
    // Overload of []
    a[2][1] = 2.5;
    a[2][2] = a[2][1];
    cout << "\n" << a << endl;

    // Create b matrix and add it to a and save result inn matrix c
    Matrix b(4, 3, 1.0);
    Matrix c = a + b;
    cout << "\n" << c << '\n';


    cout << "\n";
    cout << "====[ end ]====" << endl;
    cout << "               " << endl;

    return 0;
}

