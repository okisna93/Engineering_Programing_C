[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=8828025&assignment_repo_type=AssignmentRepo)
## Edit_first_name Edit_last_name - 2 points Please edit your name here.

# Assignment 6


# Problem/Question:
- Problem:
  - Design Zebra class that contains of the following:
    - private attributes members Zebra "name" and Zebra "count" static variable
    - default constructor that takes no argument and return nothing
    - non-default constructor that takes Zebra "name" as string, increase Zebra "count" by one, and display a message to the user " Hello I am just born, my name is [name of the zebra]"
    - create destructor that decrease the number of Zebra by one and display a message to the user
    "Ugh! I am dying, the count now is [count]
  - Creat void function f() that when called it create two Zebra objects and cout the current count
  - Design ZebraKib class that inherit all Zebra function. You should be able to run Zerbar functions on ZebraKid object
  - follow the main.cpp for more detailed instructions

Hint for problem one:
- use static attribute member of the class for the "count"
- use static method member of the class to return the "count"
  

## TO-DO:
  - clone your repo to your local computer
    - ''' <b>git clone repo_https_url</b> '''
    - repo https url is found under code tab in your github
  - Edit your name on top on README.md file.
  - Edit the main function (file name: main.cpp):
    - Write your f function, class Zebra, and class ZebraKid in main.cpp
  - Push your answers
    - use git in your terminal to add files, and add comments on your commits, and finally submit files
      - ''' <b>git add specific_file1.x specific_file2.x</b> '''
      - ''' <b>git commit -m "add message here for commits"</b> '''
      - ''' <b>git push</b> ''' 
     
    
      
    
