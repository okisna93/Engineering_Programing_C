#ifndef FUNCTIONSUM_H
#define FUNCTIONSUM_H

int sumUpTo(int x);
float sumReciprocalNormal(int x);
float sumReciprocalRev(int x);
float sumMysteryNormal(int x);
float sumMysteryRev(int x);

#endif
